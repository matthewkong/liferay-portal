AUI Data Type
========

@VERSION@
------

	* #AUI-1027 aui-datepicker outputs incorrect values when mask contains "%b %e %m"
	* #AUI-978 DateParser is returning the current date when the parsing fails
